package com.mastek.serviceImpl;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.UUID;

import org.hibernate.validator.internal.util.logging.Log;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mastek.model.Role;
import com.mastek.model.User;
import com.mastek.repo.RoleRepository;
import com.mastek.repo.UserRepository;
import com.mastek.service.UserService;

import lombok.extern.slf4j.Slf4j;

@Service
@Transactional
public class UserServiceImpl implements UserService, UserDetailsService {
	private final UserRepository userRepository;
	private final RoleRepository roleRepository;
	private final PasswordEncoder passwordEncoder;
	
	@Autowired
	public UserServiceImpl(UserRepository userRepository, RoleRepository roleRepository,
			PasswordEncoder passwordEncoder) {
		super();
		this.userRepository = userRepository;
		this.roleRepository = roleRepository;
		this.passwordEncoder = passwordEncoder;
	}

	@Override
	public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
		User user = userRepository.findByEmail(email);
		if (user == null) {
//			log.error("User not found in the database");
			throw new UsernameNotFoundException("User not found in the database");
		} else {
//			Log.info("user found in the database: {}");
		}
		Collection<SimpleGrantedAuthority> authorities = new ArrayList<>();
		user.getRoles().forEach(role -> {
			authorities.add(new SimpleGrantedAuthority(role.getName()));
		});
		return new org.springframework.security.core.userdetails.User(user.getEmail(), user.getPassword(),
				authorities);
	}

	

	@Override
	public User saveUser(User user) {
//		Log.info("saving new user{}	to the database");
		user.setPassword(passwordEncoder.encode(user.getPassword()));
		return userRepository.save(user);
	}
	
	@Override
	public Role saveRole(Role role) {
		
		return roleRepository.save(role);
	}
	
	@Override
	public void addRoleToUser(String email,String roleName) {
		User user=userRepository.findByEmail(email);
		Role role = roleRepository.findByName(roleName);
		user.getRoles().add(role);
	}

	@Override
	public User getUser(String email) {
		// TODO Auto-generated method stub
//		Log.info("Fetching user {}");
		return userRepository.findByEmail(email);
	}

	@Override
	public List<User> getusers() {
//		Log.info("Fetching all users");
		return userRepository.findAll();
	}

	
	

}
