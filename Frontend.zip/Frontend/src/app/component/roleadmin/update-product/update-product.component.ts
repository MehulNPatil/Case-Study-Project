import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Product } from 'src/app/product';
import { ApiService } from 'src/app/service/api.service';

@Component({
  selector: 'app-update-product',
  templateUrl: './update-product.component.html',
  styleUrls: ['./update-product.component.scss']
})
export class UpdateProductComponent implements OnInit {
  product = new Product();

  constructor(private _route: Router, private api: ApiService, private _activatedRoute: ActivatedRoute, private formBuilder: FormBuilder) { }

  ngOnInit(): void {
    let id = parseInt(this._activatedRoute.snapshot.paramMap.get('id') || '{}');
    this.api.getProductById(id).subscribe(

      data => {
        console.log("data received");
        this.product = data;
      },
      error => console.log("exception occured")
    )
  }

  updateProduct(product) {
    product=product.value;
    this.api.updateProduct(product).subscribe(


      data => {
        console.log("data added successfully");
        this._route.navigate(['updateproduct'])
      },

      error => console.log(error)


    )

  }
    gotolist() {
      console.log('go back');
      this._route.navigate(['productlist'])

    }

}
