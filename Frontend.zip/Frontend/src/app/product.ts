export class Product {
  id?:number ;
  category?:number;
  description?:string;
  title?:string;
  price?:number;
  image?:string;



}
