import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-header-product',
  templateUrl: './header-product.component.html',
  styleUrls: ['./header-product.component.scss']
})
export class HeaderProductComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
