package com.mastek;

import java.util.Arrays;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
import org.springframework.web.filter.CorsFilter;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

@SpringBootApplication
@EnableSwagger2
public class YourstepApplication {

	public static void main(String[] args) {
		SpringApplication.run(YourstepApplication.class, args);
	}

//	
	@Bean
	PasswordEncoder passwordEncoder() {
		return new BCryptPasswordEncoder();
	}
	
	@Bean
	public Docket productApi() {
	return new Docket(DocumentationType.SWAGGER_2).select()
	.apis(RequestHandlerSelectors.basePackage("com.mastek")).build();
	}
	
//	@Bean
//	public WebMvcConfigurer Configure() {
//		return new WebMvcConfigurer() {
//			@Override
//			public void addCorsMappings(CorsRegistry registry) {
//				registry.addMapping("/*").allowedOrigins("*");
//			}
//		};
//	}

//	@Bean
//	public CorsFilter corsFilter() {
//		CorsConfiguration corsConfiguration = new CorsConfiguration();
//		corsConfiguration.setAllowCredentials(true);
//		corsConfiguration.setAllowedOrigins(Arrays.asList("http://localhost:4200"));
//		corsConfiguration.setAllowedHeaders(Arrays.asList("Origin", "Access-Control-Allow-Origin", "Content-Type",
//				"Accept", "Authorization", "Origin, Accept", "X-Requested-With", "Access-Control-Request-Method",
//				"Access-Control-Request-Headers"));
//		corsConfiguration.setExposedHeaders(Arrays.asList("Origin", "Content-Type", "Accept", "Authorization",
//				"Access-Control-Allow-Origin", "Access-Control-Allow-Origin", "Access-Control-Allow-Credentials"));
//		corsConfiguration.setAllowedMethods(Arrays.asList("GET", "POST", "PUT", "DELETE", "OPTIONS"));
//		UrlBasedCorsConfigurationSource urlBasedCorsConfigurationSource = new UrlBasedCorsConfigurationSource();
//		urlBasedCorsConfigurationSource.registerCorsConfiguration("/**", corsConfiguration);
//		return new CorsFilter(urlBasedCorsConfigurationSource);
//	}

//	@Bean
//	CommandLineRunner run(UserService userService) {
//		return args -> {
//			userService.saveRole(new Role(null, "ROLE_USER"));
//			userService.saveRole(new Role(null, "ROLE_MANAGER"));
//			userService.saveRole(new Role(null, "ROLE_ADMIN"));
//			userService.saveRole(new Role(null, "ROLE_SUPER_ADMIN"));
//			
//			userService.saveUser(new User(null,"john smith","john@gmail.com","12345", new ArrayList<>()));
//			userService.saveUser(new User(null,"will gates","will@gmail.com","12345", new ArrayList<>()));
//			userService.saveUser(new User(null,"june george","june@gmail.com","12345", new ArrayList<>()));
//			userService.saveUser(new User(null,"may eve","may@gmail.com","12345", new ArrayList<>()));
//			userService.saveUser(new User(null,"april mali","april@gmail.com","12345", new ArrayList<>()));
//			userService.saveUser(new User(null,"sky mali","sky@gmail.com","12345", new ArrayList<>()));
//			
//			userService.addRoleToUser("john", "ROLE_USER");
//			userService.addRoleToUser("will", "ROLE_USER");
//			userService.addRoleToUser("will", "ROLE_MANAGER");
//
//			userService.addRoleToUser("june", "ROLE_USER");
//			userService.addRoleToUser("may", "ROLE_ADMIN");
//			userService.addRoleToUser("april", "ROLE_SUPER_ADMIN");
//			userService.addRoleToUser("sky", "ROLE_ADMIN");
//			userService.addRoleToUser("sky", "ROLE_SUPER_ADMIN");
//			userService.addRoleToUser("sky", "ROLE_USER");
//
//			
//		};
//	}

}
