import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { UserService } from 'src/app/component/shared/user.service';

@Component({
  selector: 'app-roleadmin',
  templateUrl: './roleadmin.component.html',
  styleUrls: ['./roleadmin.component.css']
})

export class RoleAdminComponent implements OnInit {

  constructor(private router: Router, private user: UserService) { }

  ngOnInit(): void {

  }
}
