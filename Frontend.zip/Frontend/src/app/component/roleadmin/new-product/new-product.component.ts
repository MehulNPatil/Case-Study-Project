import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { Product } from 'src/app/product';
import { ApiService } from 'src/app/service/api.service';

@Component({
  selector: 'app-new-product',
  templateUrl: './new-product.component.html',
  styleUrls: ['./new-product.component.scss'],
})
export class NewProductComponent implements OnInit {
  product = new Product();
  newproduct: FormGroup;

  constructor(
    private _route: Router,
    private api: ApiService,
    private formBuilder: FormBuilder
  ) {
    this.newproduct = this.formBuilder.group({
      id: [],
      category: [],
      description: [''],
      title: [''],
      image: [''],
      price: [''],
    });
  }

  ngOnInit(): void {}

  newProduct() {
    console.log(this.newproduct.value);

    this.api.newProduct(this.product).subscribe(
      (data) => {
        alert('data added successfully');
        this._route.navigate(['productlist']);
      },
      (error) => console.log('error')
    );
  }

  gotolist() {
    console.log('go back');
    this._route.navigate(['productlist']);
  }
}
