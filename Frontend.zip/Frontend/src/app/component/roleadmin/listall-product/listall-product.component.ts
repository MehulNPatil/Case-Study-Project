import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Product } from 'src/app/product';
import { ApiService } from 'src/app/service/api.service';

@Component({
  selector: 'app-listall-product',
  templateUrl: './listall-product.component.html',
  styleUrls: ['./listall-product.component.scss'],
})
export class ListallProductComponent implements OnInit {
  public productList: any;
  public filterCategory: any;
  constructor(private api: ApiService, private _route: Router) {}

  ngOnInit(): void {
    this.api
      .getProduct()

      .subscribe((res) => {
        this.productList = res;

        this.filterCategory = res;

        this.productList.forEach((a: any) => {
          if (
            a.category === "women's clothing" ||
            a.category === "men's clothing"
          ) {
            a.category = 'fashion';
          }

          Object.assign(a, { quantity: 1, total: a.price });
        });
      });
  }

  newProduct() {
    this._route.navigate(['/product']);
  }

  updateProduct(id: Product) {
    console.log('id' + id);

    this._route.navigate(['/product', id]);
  }

  deleteProduct(id: number) {
    this.api.deleteProductById(id).subscribe(
      (data) => {
        alert('deleted succesfully');
        this._route.navigate(['/product/', id]);
      },

      (error) => console.log('exception occured')
    );
  }
}
