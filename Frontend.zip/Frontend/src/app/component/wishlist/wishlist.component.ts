// import { Component, OnInit } from '@angular/core';

// @Component({
//   selector: 'app-wishlist',
//   templateUrl: './wishlist.component.html',
//   styleUrls: ['./wishlist.component.scss']
// })
// export class WishlistComponent implements OnInit {

//   arrdata: any;
//   i = 0;

//   constructor(private wishlistService:WishlistService,private cartService:CartService) { }
//   public products: any = [];
//   ngOnInit(): void {
//     this.wishlistService.getWishlist()
//       .subscribe(res => {
//         this.products = res;
//       })
//     console.log(this.products)
//   }
//   removeItem(item: any) {
//     this.wishlistService.removeOneFromWishlist(item);

//   }
//   addtoCart(item:any) {
//     this.cartService.addtoCart(item);
//     this.i = this.i + 1;
//     let data = {
//       category: item.category,
//       description: item.description,
//       id: item.id,
//       image: item.image,
//       price: item.price,
//       quantity: item.quantity,
//       name: item.name,
//     }

//     localStorage.setItem('item', JSON.stringify(data))
//     this.arrdata.push(
//       // localStorage.setItem('item',JSON.stringify(data))
//     );

//     // localStorage.setItem('item',JSON.stringify(data))

//   }

// }
