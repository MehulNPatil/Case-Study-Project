import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CartService } from 'src/app/service/cart.service';
import { UserService } from '../shared/user.service';
// import { WishlistService } from 'src/app/component/wishlist';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {

  public totalItem : number = 0;
  public searchTerm !: string;
  public isAdmin : boolean= false;
  constructor(private cartService : CartService, private userService: UserService, private router: Router) { }

  ngOnInit(): void {
    this.cartService.getProducts()
    .subscribe(res=>{
      this.totalItem = res.length;
    })
    // this.wishListService.getWishlist()
    // .subscribe(res=>{
    //   this.totalItemWishList=res.length;
    // })
    const userPayload = this.userService.getUserPayload();
    this.isAdmin = (userPayload && Array.isArray(userPayload.roles) && userPayload.roles.includes('ROLE_ADMIN')) || false;
  }
  search(event:any){
    this.searchTerm = (event.target as HTMLInputElement).value;
    console.log(this.searchTerm);
    this.cartService.search.next(this.searchTerm);
  }

  onLogout(){
    this.userService.deleteToken();
    this.router.navigate(['/login']);
  }
}
