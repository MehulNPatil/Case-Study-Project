export class Order {
  id?:number ;
  product_id?:number;
  quntity?:number;
  user_id?:number;




}
