import { Component, OnInit } from '@angular/core';
import { ApiService } from 'src/app/service/api.service';

@Component({
  selector: 'app-cart-product',
  templateUrl: './cart-product.component.html',
  styleUrls: ['./cart-product.component.scss']
})
export class CartProductComponent implements OnInit {
  public orderList:any;
  constructor(private api:ApiService) { }

  ngOnInit(): void {
    this.api.getOrders().subscribe(res=>{
      this.orderList=res;
    });
  }

}
