import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import {map} from 'rxjs/operators';
import { environment } from 'src/environments/environment';
import { Product } from '../product';
@Injectable({
  providedIn: 'root'
})
export class ApiService {

  constructor(private http : HttpClient) { }

  getProduct(){

    return this.http.get(environment.newApiBasrUrl+"/products")

    .pipe(map((res:any)=>{
      return res;
    }))
  }

  newProduct(product: Product){
    return this.http.post(`${environment.newApiBasrUrl}/product/`,product)
  }

  deleteProductById(id:number){

    return this.http.delete(`${environment.newApiBasrUrl}/product/`+id)

  }

  updateProduct(product: Product){
    return this.http.put(`${environment.newApiBasrUrl}/product/${product.id}/`,product)
  }

  getProductById(id:number){

    return this.http.get(`${environment.newApiBasrUrl}/product/{id}/`+id);

  }
  getOrders(){

    return this.http.get(`${environment.newApiBasrUrl}/orders`);

  }

}
