package com.mastek.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mastek.model.Cart;
import com.mastek.service.CartService;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/api")
public class CartController implements CartService{
	
	@Autowired
	CartService cartService;

	@Override
	@PostMapping("/order")
	public Cart addToCart(@RequestBody Cart order) {
		return cartService.addToCart(order);
	}

	@Override
	@GetMapping("/order/{id}")
	public Cart getCart(@PathVariable Long id) {
		return cartService.getCart(id);
	}

	@Override
	@PutMapping("/order")
	public Cart updateCart(@RequestBody Cart order) {
		// TODO Auto-generated method stub
		return cartService.updateCart(order);
	}

	@Override
	@DeleteMapping("/order/{id}")
	public void deleteCart(@PathVariable Long id) {
		// TODO Auto-generated method stub
		cartService.deleteCart(id);
	}

	@Override
	@GetMapping("/orders")
	public List<Cart> getAllOrders() {
		// TODO Auto-generated method stub
		return cartService.getAllOrders();
	}

	@Override
	@GetMapping("/orders/product/{id}")
	public List<Cart> getAllOrdersByProductId(@PathVariable Long id) {
		// TODO Auto-generated method stub
		return cartService.getAllOrdersByProductId(id);
	}

	@Override
	@GetMapping("/orders/user/{id}")
	public List<Cart> getAllOrdersByUserId(@PathVariable Long id) {
		// TODO Auto-generated method stub
		return cartService.getAllOrdersByUserId(id);
	}
	
}
