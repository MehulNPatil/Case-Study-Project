package com.mastek.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.mastek.model.Cart;


@Service
public interface CartService {
	public Cart addToCart(Cart order);
	public Cart getCart(Long id);
	public Cart updateCart(Cart order);
	public void deleteCart(Long id);
	
	public List<Cart> getAllOrders();
	public List<Cart> getAllOrdersByProductId(Long id); 
	public List<Cart> getAllOrdersByUserId(Long id);
}
