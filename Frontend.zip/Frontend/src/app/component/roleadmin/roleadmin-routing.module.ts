import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { RoleAdminComponent } from './roleadmin.component';
import { ListallProductComponent } from './listall-product/listall-product.component';
import { NewProductComponent } from './new-product/new-product.component';
import { UpdateProductComponent } from './update-product/update-product.component';
import { ViewProductComponent } from './view-product/view-product.component';
import { CartProductComponent } from './cart-product/cart-product.component';

const routes: Routes = [{ path: '', component: RoleAdminComponent },
{ path: 'listall', component: ListallProductComponent },
{ path: 'newproduct', component: NewProductComponent },
{ path: 'updateproduct/:id', component: UpdateProductComponent },
{ path: 'updateproduct', component: UpdateProductComponent },
{ path: 'viewproduct', component: ViewProductComponent },
{ path:'orders', component: CartProductComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class RoleAdminRoutingModule { }
