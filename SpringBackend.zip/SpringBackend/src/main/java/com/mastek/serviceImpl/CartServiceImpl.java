package com.mastek.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mastek.model.Cart;
import com.mastek.repo.CartRepository;
import com.mastek.service.CartService;

@Service
public class CartServiceImpl implements CartService{
	
	@Autowired
	private CartRepository cartRepository;
	
	public CartServiceImpl() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public Cart addToCart(Cart order) {
		// TODO Auto-generated method stub
		return cartRepository.save(order);
	}

	@Override
	public Cart getCart(Long id) {
		// TODO Auto-generated method stub
		return cartRepository.findById(id).orElse(null);
	}

	@Override
	public Cart updateCart(Cart order) {
		// TODO Auto-generated method stub
		return cartRepository.save(order);
	}

	@Override
	public void deleteCart(Long id) {
		cartRepository.delete(this.getCart(id));
		
	}

	@Override
	public List<Cart> getAllOrders() {
		// TODO Auto-generated method stub
		return cartRepository.findAll();
	}

	@Override
	public List<Cart> getAllOrdersByProductId(Long id) {
		// TODO Auto-generated method stub
		return cartRepository.findAllByProductId(id);
	}

	@Override
	public List<Cart> getAllOrdersByUserId(Long id) {
		// TODO Auto-generated method stub
		return cartRepository.findAllByUserId(id);
	}

}
