import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { RoleAdminComponent } from './roleadmin.component';
import { NewProductComponent } from './new-product/new-product.component';
import { UpdateProductComponent } from './update-product/update-product.component';
import { HeaderProductComponent } from './header-product/header-product.component';
import { HomeProductComponent } from './home-product/home-product.component';
import { CartProductComponent } from './cart-product/cart-product.component';
import { ListallProductComponent } from './listall-product/listall-product.component';
import { ViewProductComponent } from './view-product/view-product.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RoleAdminRoutingModule } from './roleadmin-routing.module';



@NgModule({
  declarations: [
    RoleAdminComponent,
    NewProductComponent,
    UpdateProductComponent,
    HeaderProductComponent,
    HomeProductComponent,
    CartProductComponent,
    ListallProductComponent,
    ViewProductComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    RoleAdminRoutingModule

  ]
})
export class RoleAdminModule { }
