import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ListallProductComponent } from './listall-product.component';

describe('ListallProductComponent', () => {
  let component: ListallProductComponent;
  let fixture: ComponentFixture<ListallProductComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ListallProductComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ListallProductComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
